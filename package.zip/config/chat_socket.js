module.exports.chatSockets = function(socketServer){
    let io = require('socket.io')(socketServer);
    io.sockets.on('connection',function(socket){
        console.log("new connection established");
        socket.on('disconnect',function(){
            console.log("connection disconneted");
        });
        // socket.on('join_room',function)
    });
        
}